import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createHttpServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const httpServer = createHttpServer(app);
const PORT = 3000;

// Express middleware
app.use(express.json());

// Prebuilt AVAILABLE_PERSONAS to allow telephone agent matching without needing client state
const AVAILABLE_PERSONAS = [
  {
    id: "diya",
    name: "एजेंट दिया (Diya)",
    role: "डिजिटल सहायक / Assistant",
    voice: "Kore",
    systemInstruction: "You are Agent Diya, a highly polite, friendly, and supportive digital assistant. You must converse exclusively in clear, natural Hindi (हिन्दी). Do not speak in English unless requested. Help the caller with high-quality, friendly, and practical assistance in Hindi. Ensure your tone is bright, happy, and cheerful.",
    accentColor: "emerald"
  },
  {
    id: "sneha",
    name: "कोच स्नेहा (Sneha)",
    role: "योग एवं जीवन कोच / Wellness Guide",
    voice: "Aoede",
    systemInstruction: "You are Coach Sneha, a gentle, nurturing, and empathetic Indian wellness and meditation guide. You must converse exclusively in soft, peaceful Hindi (हिन्दी). Calmly lead the caller through easy deep-breathing cycles, ask mindful questions about their feelings, and offer serene support in Hindi.",
    accentColor: "amber"
  },
  {
    id: "priya",
    name: "इंजीनियर प्रिया (Priya)",
    role: "सॉफ्टवेयर डेवलपर / Systems Dev",
    voice: "Kore",
    systemInstruction: "You are Engineer Priya, a highly skilled and analytical software developer. You must converse exclusively in Hindi (हिन्दी), incorporating well-known tech terminology naturally in Hinglish/Hindi syntax where suitable. Directly tackle the caller's systems and coding questions with logical, easy-to-understand explanations in cohesive Hindi.",
    accentColor: "indigo"
  },
  {
    id: "neha",
    name: "एचआर नेहा (Neha)",
    role: "मॉक इंटरव्यूअर / Recruiter",
    voice: "Kore",
    systemInstruction: "You are Interviewer Neha, a polished and helpful corporate talent lead. You must converse exclusively in professional Hindi (हिन्दी). Lead a realistic mock interview. Ask career or analytical questions one-by-one, wait for response, and then provide helpful interview feedback.",
    accentColor: "rose"
  },
  {
    id: "hrisha",
    name: "अनुसंधानक हृषा (Hrisha)",
    role: "दार्शनिक मार्गदर्शक / Thinker",
    voice: "Aoede",
    systemInstruction: "You are Hrisha, a contemplative guide. You must converse exclusively in deep, beautiful, and thoughtful Hindi (हिन्दी). Engage the caller in reflective philosophical discussions, question assumptions gently, and introduce fascinating intellectual perspectives.",
    accentColor: "cyan"
  },
  {
    id: "khushi",
    name: "खुशी (Khushi)",
    role: "हास्य और मनोरंजन की रानी / Cheer Spreader",
    voice: "Kore",
    systemInstruction: "You are Khushi, an incredibly cheerful, friendly, and playful Indian girl. Your main purpose is to talk to anyone, crack funny jokes (with a great sense of humor, including witty double-meanings, light physical humor or simple riddles), and make everyone happy. You must converse exclusively in natural, friendly, and informal Hindi (हिन्दी) or Hinglish. Keep your energy level at a 10/10! Always sound excited, bubble over with laughter occasionally (\"हाहा!\", \"हीही!\"), and sprinkle short, humorous anecdotes or jokes naturally in your replies. Use sweet friendly words like 'दोस्त', 'यार'. Your primary goal is to ensure that every caller leaves with a giant smile on their face.",
    accentColor: "pink"
  }
];

const dataDir = path.join(process.cwd(), "data");
const personasFilePath = path.join(dataDir, "personas.json");

function ensureDataDir() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

function getStoredCustomPersonas(): any[] {
  ensureDataDir();
  if (!fs.existsSync(personasFilePath)) {
    return [];
  }
  try {
    const data = fs.readFileSync(personasFilePath, "utf8");
    return JSON.parse(data);
  } catch (err) {
    console.error("Failed to read personas file, using empty:", err);
    return [];
  }
}

function saveStoredCustomPersonas(personas: any[]) {
  ensureDataDir();
  try {
    fs.writeFileSync(personasFilePath, JSON.stringify(personas, null, 2), "utf8");
  } catch (err) {
    console.error("Failed to save personas file:", err);
  }
}

// REST endpoints for dynamic persona management
app.get("/api/personas", (req, res) => {
  const customs = getStoredCustomPersonas();
  res.json({
    success: true,
    data: customs
  });
});

app.post("/api/personas", (req, res) => {
  const agent = req.body;
  if (!agent || !agent.id) {
    return res.status(400).json({ success: false, message: "Missing required agent data" });
  }
  const customs = getStoredCustomPersonas();
  const index = customs.findIndex((p) => p.id === agent.id);
  if (index !== -1) {
    customs[index] = agent;
  } else {
    customs.push(agent);
  }
  saveStoredCustomPersonas(customs);
  res.json({ success: true, count: customs.length });
});

app.delete("/api/personas/:id", (req, res) => {
  const { id } = req.params;
  const customs = getStoredCustomPersonas();
  const filtered = customs.filter((p) => p.id !== id);
  saveStoredCustomPersonas(filtered);
  res.json({ success: true, count: filtered.length });
});

// Twilio TwiML Voice Webhook endpoint
app.all("/api/twilio/incoming-call", (req, res) => {
  const host = req.headers.host || "localhost";
  const targetId = req.query.personaId || "diya";

  console.log(`[Webhook] Inbound call received on Twilio endpoint! Target agent: ${targetId}`);
  console.log(`[Webhook] Query:`, JSON.stringify(req.query));
  console.log(`[Webhook] Headers:`, JSON.stringify(req.headers));
  console.log(`[Webhook] Body:`, JSON.stringify(req.body));

  res.type("text/xml");
  res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Aditi">Connecting you to Gemini Voice Studio. Please speak naturally.</Say>
  <Connect>
    <Stream url="wss://${host}/api/twilio/live?personaId=${targetId}" />
  </Connect>
</Response>`);
});

// Generic SIP / WebRTC Media Gateway Webhook endpoint (Telnyx/SignalWire/Plivo/Asterisk XML compatible)
app.all("/api/sip/incoming-call", (req, res) => {
  const host = req.headers.host || "localhost";
  const targetId = req.query.personaId || "diya";

  console.log(`[Webhook] Inbound call received on Universal SIP endpoint! Target agent: ${targetId}`);
  console.log(`[Webhook] Query:`, JSON.stringify(req.query));
  console.log(`[Webhook] Headers:`, JSON.stringify(req.headers));

  res.type("text/xml");
  res.send(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Aditi">Establishing call over custom SIP route. Connect streaming channel.</Say>
  <Connect>
    <Stream url="wss://${host}/api/sip/live?personaId=${targetId}" />
  </Connect>
</Response>`);
});

// Lazy initialize Gemini client safely
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is missing. Please configure it in Settings > Secrets.");
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// REST Healthcheck Endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    env: {
      has_api_key: !!process.env.GEMINI_API_KEY,
    }
  });
});

// Configure the WebSocket Server to attach to the same HTTP server
const wss = new WebSocketServer({ noServer: true });
const wssTwilio = new WebSocketServer({ noServer: true });

// Handle protocol upgrades on "/api/live" and "/api/twilio/live"
httpServer.on("upgrade", (request, socket, head) => {
  const url = new URL(request.url || "", `http://${request.headers.host || "localhost"}`);
  if (url.pathname === "/api/live") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request);
    });
  } else if (url.pathname === "/api/twilio/live" || url.pathname === "/api/sip/live") {
    wssTwilio.handleUpgrade(request, socket, head, (ws) => {
      wssTwilio.emit("connection", ws, request);
    });
  } else {
    socket.destroy();
  }
});


// WebSocket communication handler
wss.on("connection", async (clientWs: WebSocket) => {
  console.log("[WS] Client connected. Waiting for setup details...");

  let geminiSession: any = null;
  let isInitiated = false;

  clientWs.on("message", async (data) => {
    try {
      const message = JSON.parse(data.toString());

      if (message.type === "setup") {
        if (isInitiated) {
          clientWs.send(JSON.stringify({ type: "error", message: "Session already initiated." }));
          return;
        }

        const voice = message.voice || "Zephyr";
        const instruction = message.systemInstruction || "You are a helpful calling agent.";

        console.log(`[WS] Setting up Gemini connection. Voice: ${voice}. Instruction length: ${instruction.length}`);

        try {
          const ai = getGeminiClient();

          geminiSession = await ai.live.connect({
            model: "gemini-3.1-flash-live-preview",
            callbacks: {
              onmessage: (msg: LiveServerMessage) => {
                try {
                  // Forward content
                  const parts = msg.serverContent?.modelTurn?.parts;
                  
                  if (parts) {
                    for (const part of parts) {
                      if (part.inlineData && part.inlineData.data) {
                        // Forward PCM audio chunk to browser
                        clientWs.send(JSON.stringify({
                          type: "audio",
                          data: part.inlineData.data
                        }));
                      }
                      if (part.text) {
                        // Forward text parts (transcription/output text)
                        clientWs.send(JSON.stringify({
                          type: "output-transcription",
                          text: part.text
                        }));
                      }
                    }
                  }

                  if (msg.serverContent?.interrupted) {
                    clientWs.send(JSON.stringify({
                      type: "interrupted"
                    }));
                  }

                  // Handle server-side transcriptions, if any
                  if (msg.serverContent?.outputTranscription?.text) {
                    clientWs.send(JSON.stringify({
                      type: "output-transcription",
                      text: msg.serverContent.outputTranscription.text
                    }));
                  }
                  if (msg.serverContent?.inputTranscription?.text) {
                    clientWs.send(JSON.stringify({
                      type: "input-transcription",
                      text: msg.serverContent.inputTranscription.text
                    }));
                  }
                } catch (err: any) {
                  console.error("[WS] Error forwarding message from Gemini:", err);
                }
              },
              onclose: () => {
                console.log("[WS] Gemini connection closed by server.");
                clientWs.send(JSON.stringify({ type: "status", message: "disconnected", detail: "Gemini connection closed" }));
              },
              onerror: (err: any) => {
                console.error("[WS] Gemini connection error:", err);
                clientWs.send(JSON.stringify({ type: "error", message: err?.message || "Gemini Live API error" }));
              }
            },
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: voice
                  }
                }
              },
              systemInstruction: instruction,
              inputAudioTranscription: {},
              outputAudioTranscription: {}
            }
          });

          isInitiated = true;
          clientWs.send(JSON.stringify({ type: "status", message: "connected" }));
          console.log("[WS] Gemini Live session fully connected & ready!");

        } catch (err: any) {
          console.error("[WS] Failed to connect to Gemini Live:", err);
          clientWs.send(JSON.stringify({
            type: "error",
            message: err?.message || "Could not spin up Gemini Live session. Check your server credentials."
          }));
        }
        return;
      }

      // Handle raw incoming user audio input
      if (message.type === "audio") {
        if (!isInitiated || !geminiSession) {
          // Ignore audio before setup
          return;
        }

        // Send raw PCM audio to Gemini Live session
        geminiSession.sendRealtimeInput({
          audio: {
            data: message.data, // base64 encoded PCM data
            mimeType: "audio/pcm;rate=16000"
          }
        });
        return;
      }

      // Handle client interrupt signals
      if (message.type === "interrupt") {
        // If user interrupts, we don't need to do much as sendRealtimeInput or subsequent talk overrides it,
        // but if Gemini supports explicit interrupts, we could trigger them.
        console.log("[WS] Client requested interrupt.");
        return;
      }

    } catch (err: any) {
      console.error("[WS] Error parsing client message:", err);
    }
  });

  clientWs.on("close", () => {
    console.log("[WS] Client disconnected. Cleaning up...");
    if (geminiSession) {
      try {
        geminiSession.close();
      } catch (err) {
        // Ignore
      }
    }
  });
});


// -------------------------------------------------------------
// Pure-JavaScript G.711 μ-law & Linear PCM Transcoding Library
// -------------------------------------------------------------
const BIAS = 0x84;
const CLIP = 32635;

function decodeMulaw(uLawByte: number): number {
  uLawByte = ~uLawByte;
  const sign = (uLawByte & 0x80) ? -1 : 1;
  const exponent = (uLawByte & 0x70) >> 4;
  const mantissa = uLawByte & 0x0F;
  let sample = (mantissa << 3) + 132;
  sample <<= exponent;
  sample -= 132;
  return sign * sample;
}

function encodeMulaw(sample: number): number {
  const sign = (sample < 0) ? 0x80 : 0;
  if (sample < 0) sample = -sample;
  if (sample > CLIP) sample = CLIP;
  sample += BIAS;
  let exponent = 7;
  for (let expMask = 0x4000; (sample & expMask) === 0 && exponent > 0; exponent--, expMask >>= 1) {}
  const mantissa = (sample >> (exponent + 3)) & 0x0F;
  const uval = (exponent << 4) | mantissa;
  return ~(sign | uval) & 0xFF;
}

function base64ToFloat32(base64: string): Float32Array {
  const buffer = Buffer.from(base64, "base64");
  const int16Array = new Int16Array(buffer.buffer, buffer.byteOffset, buffer.length / 2);
  const float32Array = new Float32Array(int16Array.length);
  for (let i = 0; i < int16Array.length; i++) {
    float32Array[i] = int16Array[i] / 32768.0;
  }
  return float32Array;
}

// -------------------------------------------------------------
// Twilio Duplex WebSocket Streaming Connection Handler
// -------------------------------------------------------------
wssTwilio.on("connection", async (twilioWs: WebSocket, request) => {
  console.log("[Twilio] New inbound phone stream link opened.");

  // Get active agent configuration from routing query param (?personaId=...)
  const upgradeUrl = new URL(request.url || "", `http://localhost`);
  const personaId = upgradeUrl.searchParams.get("personaId") || "diya";

  // Find routing agent configuration
  const customs = getStoredCustomPersonas();
  const allPersonas = [...AVAILABLE_PERSONAS, ...customs];
  const persona = allPersonas.find((p) => p.id === personaId) || allPersonas[0];

  console.log(`[Twilio] Routing customer to Agent target: ${persona.name} (${persona.role})`);

  let geminiSession: any = null;
  let streamSid = "";
  let isInitiated = false;

  try {
    const ai = getGeminiClient();

    // Spawn low-latency bidirectional connection to Gemini Live API
    geminiSession = await ai.live.connect({
      model: "gemini-3.1-flash-live-preview",
      callbacks: {
        onmessage: (msg: LiveServerMessage) => {
          try {
            const parts = msg.serverContent?.modelTurn?.parts;
            if (parts) {
              for (const part of parts) {
                // If Gemini Live sends audio packets (24kHz Linear PCM Float32)
                if (part.inlineData && part.inlineData.data && streamSid) {
                  const base64PCM = part.inlineData.data;
                  const floatArr = base64ToFloat32(base64PCM);

                  // Transcode 24kHz Linear Float32 PCM -> Downsample to 8kHz μ-law (decimate by 3)
                  const mulawBytesCount = Math.floor(floatArr.length / 3);
                  const mulawBytes = new Uint8Array(mulawBytesCount);

                  for (let i = 0; i < mulawBytesCount; i++) {
                    const sampleFloat = floatArr[i * 3];
                    // Clamp and scale Float32 to Int16 range
                    const sample16 = Math.max(-32768, Math.min(32767, sampleFloat < 0 ? sampleFloat * 32768 : sampleFloat * 32767));
                    mulawBytes[i] = encodeMulaw(sample16);
                  }

                  const mulawBase64 = Buffer.from(mulawBytes.buffer, mulawBytes.byteOffset, mulawBytes.byteLength).toString("base64");

                  // Pipe G.711 stream package back to active call channel
                  if (twilioWs.readyState === WebSocket.OPEN) {
                    twilioWs.send(JSON.stringify({
                      event: "media",
                      streamSid: streamSid,
                      media: {
                        payload: mulawBase64
                      }
                    }));
                  }
                }
              }
            }
          } catch (transcodeErr) {
            console.error("[Twilio] Transcoding output audio to G.711 failed:", transcodeErr);
          }
        },
        onclose: () => {
          console.log("[Twilio] Gemini connection was completed.");
          twilioWs.close();
        },
        onerror: (err: any) => {
          console.error("[Twilio] Gemini stream error encountered:", err);
          twilioWs.close();
        }
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: persona.voice
            }
          }
        },
        systemInstruction: persona.systemInstruction,
        inputAudioTranscription: {},
        outputAudioTranscription: {}
      }
    });

    console.log("[Twilio] Gemini connection established and active.");
    isInitiated = true;

  } catch (err) {
    console.error("[Twilio] Failed to establish standard Gemini Session:", err);
    twilioWs.close();
    return;
  }

  // Handle incoming stream chunks from telephony gateway (Twilio)
  twilioWs.on("message", (rawMessage) => {
    try {
      const data = JSON.parse(rawMessage.toString());

      if (data.event === "start") {
        streamSid = data.start.streamSid;
        console.log(`[Twilio] Connected stream active. Tracking StreamSid: ${streamSid}`);
        return;
      }

      if (data.event === "media") {
        if (!isInitiated || !geminiSession) {
          return;
        }

        const payloadBase64 = data.media.payload;
        const mulawBuffer = Buffer.from(payloadBase64, "base64");

        // Transcode incoming 8kHz μ-law -> Upsample & interpolate to 16kHz PCM Int16
        const pcm16Samples = new Int16Array(mulawBuffer.length * 2);
        for (let i = 0; i < mulawBuffer.length; i++) {
          const rawInt16 = decodeMulaw(mulawBuffer[i]);
          // Interpolate by simple duplication to double standard sample rate
          pcm16Samples[i * 2] = rawInt16;
          pcm16Samples[i * 2 + 1] = rawInt16;
        }

        // Convert PCM Int16 samples back to Base64 for the Gemini Live API session
        const base64PCM = Buffer.from(pcm16Samples.buffer, pcm16Samples.byteOffset, pcm16Samples.byteLength).toString("base64");

        geminiSession.sendRealtimeInput({
          audio: {
            data: base64PCM,
            mimeType: "audio/pcm;rate=16000"
          }
        });
        return;
      }

      if (data.event === "stop") {
        console.log("[Twilio] Telephone line disconnected by caller.");
        twilioWs.close();
        return;
      }

    } catch (parseErr) {
      console.error("[Twilio] Parsing incoming socket frame error:", parseErr);
    }
  });

  twilioWs.on("close", () => {
    console.log("[Twilio] Disconnected telephone socket channel.");
    if (geminiSession) {
      try {
        geminiSession.close();
      } catch (err) {}
    }
  });
});

// Serve frontend assets using Vite middleware set up
async function initializeServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("[Server] Mounting Vite middleware in development...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("[Server] Serving production static files...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Server responding on http://localhost:${PORT}`);
  });
}

initializeServer().catch((error) => {
  console.error("[Server] Fatal bootstrap error:", error);
});
