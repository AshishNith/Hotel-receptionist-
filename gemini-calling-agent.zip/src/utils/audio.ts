/**
 * Convert a Float32Array of audio samples in range [-1.0, 1.0] to an ArrayBuffer
 * containing 16-bit Signed Integers (PCM Int16).
 */
export function float32ToInt16(floatArr: Float32Array): ArrayBuffer {
  const buffer = new ArrayBuffer(floatArr.length * 2);
  const view = new DataView(buffer);
  for (let i = 0; i < floatArr.length; i++) {
    // Clamp sample values between -1.0 and 1.0
    const s = Math.max(-1, Math.min(1, floatArr[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true); // true for little-endian
  }
  return buffer;
}

/**
 * Encodes an ArrayBuffer (or typed array) to a Base64 string.
 */
export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Decodes a Base64 encoded 16-bit Signed Int PCM string back into a Float32Array
 * for playout in standard Web Audio API.
 */
export function base64ToFloat32(base64: string): Float32Array {
  const binary = atob(base64);
  const len = binary.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  // Convert byte stream to Int16
  const int16Array = new Int16Array(bytes.buffer);
  const float32Array = new Float32Array(int16Array.length);
  for (let i = 0; i < int16Array.length; i++) {
    float32Array[i] = int16Array[i] / 32768.0;
  }
  return float32Array;
}
