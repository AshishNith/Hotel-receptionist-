import React from "react";
import { Persona } from "../types";
import { Activity, ShieldCheck, Database, HardDriveDownload } from "lucide-react";

interface CallStatsProps {
  callState: "idle" | "calling" | "connected" | "ended" | "error";
  persona: Persona;
  packetCount: number;
}

export const CallStats: React.FC<CallStatsProps> = ({
  callState,
  persona,
  packetCount,
}) => {
  return (
    <div className="bg-white/[0.02] backdrop-blur-2xl border border-white/5 rounded-3xl p-5 shadow-2xl shadow-black/85">
      <h3 className="text-[10px] font-semibold tracking-[0.2em] text-zinc-500 uppercase mb-3 flex items-center gap-2 font-mono">
        <Activity className="w-3.5 h-3.5 text-orange-400" /> Secure Trunk Telemetry Metrics
      </h3>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1 */}
        <div className="bg-[#0a0502]/60 p-4 rounded-2xl border border-white/5 font-mono">
          <span className="text-[9px] text-zinc-500 uppercase tracking-widest block">Trunk Codec</span>
          <span className="text-xs font-semibold text-zinc-200 mt-1 block">
            {callState === "connected" ? "PCM Mono 16kHz" : "Awaiting Dial..."}
          </span>
        </div>

        {/* Stat 2 */}
        <div className="bg-[#0a0502]/60 p-4 rounded-2xl border border-white/5 font-mono">
          <span className="text-[9px] text-zinc-500 uppercase tracking-widest block">Safety Layer</span>
          <span className="text-xs font-semibold text-zinc-200 mt-1 block flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-green-400 inline shrink-0" />
            <span>TLS-1.3 Secure VoIP</span>
          </span>
        </div>

        {/* Stat 3 */}
        <div className="bg-[#0a0502]/60 p-4 rounded-2xl border border-white/5 font-mono">
          <span className="text-[9px] text-zinc-500 uppercase tracking-widest block">AI Registry</span>
          <span className="text-xs font-semibold text-zinc-200 mt-1 block truncate">
            {callState === "connected" ? "gemini-2.0-flash-exp" : "Link Core Offline"}
          </span>
        </div>

        {/* Stat 4 */}
        <div className="bg-[#0a0502]/60 p-4 rounded-2xl border border-white/5 font-mono">
          <span className="text-[9px] text-zinc-400 uppercase tracking-widest block flex items-center gap-1.5">
            <HardDriveDownload className="w-3 h-3 text-orange-400" /> Packets Transceiving
          </span>
          <span className="text-xs font-bold text-orange-400 mt-1 block">
            {packetCount > 0 ? `${packetCount} cells stream` : "0 frames data"}
          </span>
        </div>
      </div>
    </div>
  );
};
